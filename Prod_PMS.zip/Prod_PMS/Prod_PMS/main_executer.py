import sys
from datetime import datetime 
from concurrent.futures import ThreadPoolExecutor

"""Ensure path properlly appended"""
sys.path.append('.')
from src.initialization.folder import df,destination_path
from src.initialization import vMain
from src.database.models import get_session, get_db_engine
from src.database.helpers import Status_log_entry
from src.reusable import Email_Automation

Email_Automation.start_Mail("THIRD PARTY")

class main_file_constants:
    DB_SESSION = get_session(get_db_engine())

Status_log_entry(main_file_constants.DB_SESSION, datetime.now(), "PMS Process", "Main PMS Process", "Third Party", "rpa.consultant@360.one", "Started", "Main PMS process bot started")
with ThreadPoolExecutor(max_workers=2) as executor:
    futures = []
    for _, row in df.iterrows():
        FUND = row.iloc[0]
        if FUND == "CARNELIAN PMS":
            futures.append(executor.submit(vMain.run_carnelian, row))
        elif FUND == "ASK PMS":
            futures.append(executor.submit(vMain.run_ask, row))
        elif FUND == "PRUDENT PMS":
            futures.append(executor.submit(vMain.run_carnelian, row))
        elif FUND == "HELIOS PMS":
            futures.append(executor.submit(vMain.run_helois, row))
        elif FUND == "MARCELLUS PMS":
            futures.append(executor.submit(vMain.run_Marcellus, row))
        elif FUND == "UNIFI PMS":
            futures.append(executor.submit(vMain.run_unifi, row))
        elif FUND == "WHITE OAK PMS":
            futures.append(executor.submit(vMain.run_white, row))
        elif FUND == "360 ONE AMC PMS":
            futures.append(executor.submit(vMain.run_one, row))
        elif FUND == "360 ONE CO-INVESTMENT PMS":
            futures.append(executor.submit(vMain.run_oneamc, row))
        elif FUND == "BUOYANT PMS":
            futures.append(executor.submit(vMain.run_buyant, row))
        elif FUND == "ALF ACCURATE ADVISORS PMS":
            futures.append(executor.submit(vMain.run_alf, row))
        elif FUND == "ENAM PMS":
            futures.append(executor.submit(vMain.run_enam, row))
        elif FUND == "SUNDARAM PMS":
            futures.append(executor.submit(vMain.run_sundaram, row))
        elif FUND == "OLD BRIDGE PMS":
            futures.append(executor.submit(vMain.run_old, row))
        elif FUND == "PURNARTHA PMS":
            futures.append(executor.submit(vMain.run_pur, row))
        elif FUND == "ADITYA BIRLA PMS":
            futures.append(executor.submit(vMain.run_aditya, row))
        elif FUND == "MULTI-ACT PMS":
            futures.append(executor.submit(vMain.run_multi, row))
        elif FUND == "ALCHEMY PMS":
            futures.append(executor.submit(vMain.run_alchmey, row))

    # Wait for all tasks to complete
    for future in futures:
        future.result()

df.to_excel(destination_path, index=False)
Status_log_entry(main_file_constants.DB_SESSION, datetime.now(), "PMS Process", "Main PMS Process", "Third Party", "rpa.consultant@360.one", "Successfull", "Main PMS process bot executed successfully")
Email_Automation.successMail("THIRD PARTY")