import sys
from datetime import datetime 
from concurrent.futures import ThreadPoolExecutor

"""Ensure path properlly appended"""
sys.path.append('.')
from src.initialization.folder import df,destination_path
from src.database.models import get_session, get_db_engine
from src.database.helpers import Status_log_entry
from src.reusable import Email_Automation

Email_Automation.start_Mail("THIRD PARTY")

class main_file_constants:
    DB_SESSION = get_session(get_db_engine())

Status_log_entry(main_file_constants.DB_SESSION, datetime.now(), "PMS Process", "Main PMS Process", "Third Party", "rpa.consultant@360.one", "Started", "Main PMS process bot started")

df.to_excel(destination_path, index=False)
Status_log_entry(main_file_constants.DB_SESSION, datetime.now(), "PMS Process", "Main PMS Process", "Third Party", "rpa.consultant@360.one", "Successfull", "Main PMS process bot executed successfully")
Email_Automation.successMail("THIRD PARTY")