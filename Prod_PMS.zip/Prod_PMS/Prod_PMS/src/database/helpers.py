import logging
from datetime import datetime
import psutil
import socket
import os
from sqlalchemy import exc
from src.initialization import folder_structure
from src.database.models import ProcessData, MailLog
 
"""Constants"""
date_time = datetime.now()
current_date = date_time.strftime("%d-%m-%Y")


"""Configuring log file"""
log_dir = os.path.join(os.getcwd(), 'assets', 'logs', 'error_logs', f"{folder_structure.CurrentDate_error_log_Folder}")
os.makedirs(log_dir, exist_ok=True) 
logging.basicConfig(filename=os.path.join(log_dir, 'error_log.txt'),level=logging.ERROR,format='%(asctime)s %(levelname)s:%(message)s')
 
 
def get_new_processid(session, taskname, current_date):
    try:
        date_part_filter = current_date.strftime('%Y%m%d')
        last_entry = session.query(ProcessData).filter(ProcessData.ProcessID.like(f"{date_part_filter}%")).order_by(ProcessData.ProcessID.desc()).first()
        if last_entry:
            last_processid = str(last_entry.ProcessID)
            date_part, num_part = last_processid[:-3], last_processid[-3:]
            if date_part == current_date.strftime('%Y%m%d'):
                new_num_part = str(int(num_part) + 1).zfill(3)
                return f"{date_part}{new_num_part}"
        return f"{current_date.strftime('%Y%m%d')}001"
    except Exception as e:
        logging.error(f"Error in get_new_processid: {e}")
        raise
 
 
def get_new_runid(session, taskname, current_date):
    try:
        date_part_filter = current_date.strftime('%Y%m%d')
        last_entry = session.query(ProcessData).filter(ProcessData.TaskName == taskname, ProcessData.ProcessID.like(f"{date_part_filter}%")).order_by(ProcessData.ProcessID.desc()).first()
        if last_entry:
            """Log both RunID and ProcessID clearly"""
            last_runid = int(last_entry.RunID)
            """Ensure ProcessID is a string before slicing"""
            processid_str = str(last_entry.ProcessID)
            date_part = processid_str[:-3]
            """Compare date parts and increment RunID if necessary"""
            if date_part == current_date.strftime('%Y%m%d'):
                return last_runid + 1
        return 1
    except Exception as e:
        logging.error(f"Error in get_new_runid: {e}")
        raise
 
 
def Status_log_entry(session, botend_time, processname, taskname, applicationname, loginuserid, status, description):
    current_date = datetime.now()
    try:
        if status == 'Started':
            processid = get_new_processid(session, taskname, current_date)
            runid = get_new_runid(session, taskname, current_date)
 
            new_entry = ProcessData(
                BotStart_Time=datetime.now(),
                BotEnd_Time=botend_time,
                ProcessName=processname,
                TaskName=taskname,
                ApplicationName=applicationname,
                LoginUserID=loginuserid,
                Status=status,
                Description=description,
                RunID=runid,
                ProcessID=processid,
            )
            session.add(new_entry)
            session.flush()
            session.commit()
            return new_entry
        else:
            existing_entry = session.query(ProcessData).filter(ProcessData.TaskName == taskname, ProcessData.ProcessID.like(f"{current_date.strftime('%Y%m%d')}%")).order_by(ProcessData.ProcessID.desc()).first()
            if existing_entry:
                existing_entry.BotEnd_Time = botend_time
                existing_entry.Status = status
                existing_entry.Description = description
                session.flush()
                session.commit()
                return existing_entry
    except exc.SQLAlchemyError as e:
        session.rollback()
        logging.error(f"Database Error in Status_log_entry: {e}")
        raise
    except Exception as e:
        logging.error(f"Error in Status_log_entry: {e}")
        raise
 
 
 
"""Detailed log process & run id genration..."""
 
"""Run ID And Process ID for the Detaild Logs"""
def get_new_processid_for_detailed_log(session, taskname, current_date):
    try:
        date_part_filter = current_date.strftime('%Y%m%d')
        last_entry = session.query(MailLog).filter(MailLog.ProcessID.like(f"{date_part_filter}%")).order_by(MailLog.ProcessID.desc()).first()
        if last_entry:
            last_processid = str(last_entry.ProcessID)
            date_part, num_part = last_processid[:-3], last_processid[-3:]
            if date_part == current_date.strftime('%Y%m%d'):
                new_num_part = str(int(num_part) + 1).zfill(3)
                return f"{date_part}{new_num_part}"
        return f"{current_date.strftime('%Y%m%d')}001"
    except Exception as e:
        logging.error(f"Error in get_new_mail_processid: {e}")
        raise
 
 
def get_new_runid_for_detailed_log(session, taskname, current_date):
    try:
        date_part_filter = current_date.strftime('%Y%m%d')
        last_entry = session.query(MailLog).filter(MailLog.TaskName == taskname, MailLog.ProcessID.like(f"{date_part_filter}%")).order_by(MailLog.ProcessID.desc()).first()
        if last_entry:
            last_runid = int(last_entry.RunID)
            processid_str = str(last_entry.ProcessID)
            date_part = processid_str[:-3]
            if date_part == current_date.strftime('%Y%m%d'):
                return last_runid + 1
        return 1
    except Exception as e:
        logging.error(f"Error in get_new_mail_runid: {e}")
        raise
 
 
def Detail_log_entry(session, processname, taskname, applicationname, loginuserid, recorderidentifier, description, loglevel):
    current_date = datetime.now()
    try:
        # processid = get_new_processid(session, taskname, current_date)
        # runid = get_new_runid(session, taskname, current_date)
 
        processid = get_new_processid_for_detailed_log(session, taskname, current_date)
        runid = get_new_runid_for_detailed_log(session, taskname, current_date)
 
        # processid = get_new_processid(session, taskname, current_date)
        # runid = get_new_runid_for_detailed_log(session, taskname, current_date)
 
        if loglevel != 'Started':
            existing_entry = session.query(MailLog).filter(MailLog.TaskName == taskname, MailLog.ProcessID.like(f"{current_date.strftime('%Y%m%d')}%")).order_by(MailLog.ProcessID.desc()).first()
 
            if existing_entry and str(existing_entry.ProcessID)[:-3] == current_date.strftime('%Y%m%d'):
                processid = existing_entry.ProcessID
                runid = existing_entry.RunID
 
        timestamp = datetime.now()
        systemusername = os.getlogin()
        machinename = socket.gethostname()
        cpuusage_percentage = psutil.cpu_percent(interval=1)
        ramusage_mb = psutil.virtual_memory().used // (1024 * 1024)
 
        new_entry = MailLog(
            Timestamp=timestamp,
            RunID=runid,
            SystemUsername=systemusername,
            MachineName=machinename,
            ProcessName=processname,
            TaskName=taskname,
            ApplicationName=applicationname,
            LoginUserID=loginuserid,
            RecorderIdentifier=recorderidentifier,
            Description=description,
            LogLevel=loglevel,
            cpuusage_percentage=cpuusage_percentage,
            ramusage_mb=ramusage_mb,
            ProcessID=processid,
        )
        session.add(new_entry)
        session.flush()
        session.commit()
        return new_entry
    except exc.SQLAlchemyError as e:
        session.rollback()
        logging.error(f"Database Error in Detail_log_entry: {e}")
        print(f"Database Error in Detail_log_entry: {e}")
        raise
    except Exception as e:
        logging.error(f"Error in Detail_log_entry: {e}")
        print(f"Error in Detail_log_entry: {e}")
        raise