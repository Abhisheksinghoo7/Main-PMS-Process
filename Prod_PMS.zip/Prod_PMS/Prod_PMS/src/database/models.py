from sqlalchemy import Column, VARCHAR, Integer, DateTime, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.types import VARCHAR
import os
from urllib.parse import quote_plus
Base = declarative_base()

from dotenv import load_dotenv
load_dotenv()
 
 
"""Constants"""
DATABASE_HOST = os.getenv('DATABASE_HOST')
DATABASE_NAME = os.getenv('DATABASE_NAME')
SQL_DRIVER = os.getenv('SQL_DRIVER')
 
class ProcessData(Base):
    __tablename__ = 'Bot_Status'
 
    Sr_No = Column(Integer, primary_key=True, autoincrement=True)
    BotStart_Time = Column(DateTime, nullable=True)
    BotEnd_Time = Column(DateTime, nullable=True)
    ProcessName = Column(VARCHAR(500), nullable=True)
    TaskName = Column(VARCHAR(500), nullable=True)
    ApplicationName = Column(VARCHAR(500), nullable=True)
    LoginUserID = Column(VARCHAR(500), nullable=True)
    Status = Column(VARCHAR(500), nullable=True)
    Description = Column(VARCHAR(500), nullable=True)
    RunID = Column(Integer, nullable=True)
    ProcessID = Column(VARCHAR(500), nullable=True)
 
class MailLog(Base):
    __tablename__ = 'Bot_DetailLog'
 
    Sr_No = Column(Integer, primary_key=True, autoincrement=True)
    Timestamp = Column(DateTime, nullable=True)
    RunID = Column(Integer, nullable=True)
    SystemUsername = Column(VARCHAR(500), nullable=True)
    MachineName = Column(VARCHAR(500), nullable=True)
    ProcessName = Column(VARCHAR(500), nullable=True)
    TaskName = Column(VARCHAR(500), nullable=True)
    ApplicationName = Column(VARCHAR(500), nullable=True)
    LoginUserID = Column(VARCHAR(500), nullable=True)
    RecorderIdentifier = Column(VARCHAR(500), nullable=True)
    Description = Column(VARCHAR(500), nullable=True)
    LogLevel = Column(VARCHAR(500), nullable=True)
    cpuusage_percentage = Column(Integer, nullable=True, name="CPUUsage(%)")
    ramusage_mb = Column(Integer, nullable=True, name="RAMUsage(MB)")
    ProcessID = Column(VARCHAR(500), nullable=True)

 
"""Set up SQLAlchemy engine for both SQLite and MSSQL"""
# def get_db_engine(db_type="sqlite", db_url="sqlite:///database.db"):
def get_db_engine(db_type="mssql", db_url="sqlite:///database.db"):
    if db_type == "mssql":
        connection_VARCHAR = f"mssql+pyodbc:///?odbc_connect={quote_plus(f'DRIVER={{{SQL_DRIVER}}};SERVER={DATABASE_HOST};DATABASE={DATABASE_NAME};TrustServerCertificate=yes;Trusted_Connection=yes;MARS_Connection=Yes;Connection Timeout=60;')}"
        return create_engine(connection_VARCHAR, echo=False, fast_executemany=True)
    else:
        return create_engine(db_url, echo=False)
 
 
"""Set up session for both databases"""
def get_session(engine):
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine)()