from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from src.initialization.folder import Screenshot,yesterday
import time
from src.initialization.utils import set_download_path, wait_for_download,chrome_options  # ✅ Import from utils.py

def enam_login(username, password, URL):
    """Log into the website and return the driver and wait object."""
    print("Starting login process...")
    driver = webdriver.Chrome(options=chrome_options)
    wait = WebDriverWait(driver, 30)
    error = False
    try:
        driver.get(URL)

        # Enter credentials & login
        username_field = wait.until(EC.presence_of_element_located((By.NAME, "j_username")))
        password_field = driver.find_element(By.NAME, "j_password")
        username_field.send_keys(username)
        password_field.send_keys(password)

        login_button = driver.find_element(By.XPATH, '//*[@id="inputPassword"]/div[2]/div/input')
        login_button.click()

        wait.until(EC.presence_of_element_located((By.ID, "boQueryLeftMenu"))).click()

        print(f"Login successful.{error}")
        
        return driver, wait,error
    
    except Exception as e:
        driver.save_screenshot(rf"{Screenshot}\Carlien_Login.png")
        print(f"Login failed: {e}")
        error = True
        driver.quit()
        return None, None,error

def enam_AUM(driver, wait, AUM_filename,download_dir):
    """Automates downloading the AUM report and renaming it."""
    print("Navigating to AUM Report...")
    vAumStatus = "No"
    error = False
    try:
        set_download_path(driver, download_dir)  # Set the correct directory
        
        #wait.until(EC.presence_of_element_located((By.ID, "boQueryLeftMenu"))).click()

        # Select "Clientwise Daily AUM"
        dropdown = wait.until(EC.presence_of_element_located((By.XPATH, "//select[@id='queryFile']")))
        Select(dropdown).select_by_visible_text("Clientwise Daily AUM")

        # Enter "From" and "To" dates
        from_date = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='fromDateUI']")))
        to_date = driver.find_element(By.XPATH, "//input[@id='toDateUI']")
        from_date.clear()
        from_date.send_keys(yesterday)
        from_date.send_keys(Keys.RETURN)
        to_date.clear()
        to_date.send_keys(yesterday)
        to_date.send_keys(Keys.RETURN) 

        # Select CSV output
        Select(wait.until(EC.presence_of_element_located((By.XPATH, "//select[@id='output']")))).select_by_visible_text("CSV")
        driver.save_screenshot(f"{Screenshot}\{AUM_filename}.png")
        # Click Submit and download
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, "//div[@id='myTabContent']/div[1]/div[7]/div[1]/button[1]")))
        submit_button.click()

        # Wait for file link & download
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "//tbody[@id='executionData']/tr[1]/td[3]/a[1]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        #Optional buffer time
        time.sleep(2) 

        downloaded_file = wait_for_download(download_dir,AUM_filename)
        if downloaded_file:
            pass

        vAumStatus = "Done"

    except Exception as e:
        driver.save_screenshot(rf"{Screenshot}\{AUM_filename}.png")
        print(f"Error in downloading AUM report: {e}")
        error = True
    return vAumStatus,error

def enam_Flow(driver, wait, flow_filename, download_dir1):
    """Automates downloading the Flow report and renaming it."""
    print("Navigating to Flow Report...")
    vFlowStatus = "No"
    error = False
    try:
        set_download_path(driver, download_dir1)  # Set the correct directory

        wait.until(EC.presence_of_element_located((By.ID, "boQueryLeftMenu"))).click()
        dropdown = wait.until(EC.presence_of_element_located((By.XPATH, "//select[@id='queryFile']")))
        Select(dropdown).select_by_visible_text("Client Capital Flows")

        # Enter dates
        from_date = wait.until(EC.presence_of_element_located((By.XPATH, "	//input[@id='fromDateUI']")))
        to_date = driver.find_element(By.XPATH, "//input[@id='toDateUI']")
        from_date.clear()
        from_date.send_keys("01/01/2001")
        from_date.send_keys(Keys.RETURN)
        to_date.clear()
        to_date.send_keys(yesterday)
        to_date.send_keys(Keys.RETURN) 

        # Select CSV output
        output_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, "//select[@id='output']")))
        Select(output_dropdown).select_by_visible_text("CSV")
        time.sleep(2)
        driver.save_screenshot(rf"{Screenshot}\{flow_filename}.png")
        # Click Submit
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="myTabContent"]/div/div[7]/div/button')))
        submit_button.click()

        # Wait for file link & download
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "//tbody[@id='executionData']/tr[1]/td[3]/a[1]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        time.sleep(2)  # Optional buffer time

        downloaded_file = wait_for_download(download_dir1,flow_filename)
        #if downloaded_file:
            #rename_file(download_dir1, flow_filename,"flow")
        vFlowStatus = "Done"
    except Exception as e:
        driver.save_screenshot(rf"{Screenshot}\{flow_filename}.png")
        print(f"Error in downloading Flow report: {e}")
        error = True
    return vFlowStatus,error

def enam_Master(driver, wait, Master_filename, download_dir1):
    """Automates downloading the Master report and renaming it."""
    print("Navigating to Master Report...")
    vMasterStatus = "No"
    error = False
    try:
        set_download_path(driver, download_dir1)  # Set the correct directory

        wait.until(EC.presence_of_element_located((By.ID, "boQueryLeftMenu"))).click()
        dropdown = wait.until(EC.presence_of_element_located((By.XPATH, "//select[@id='queryFile']")))
        Select(dropdown).select_by_visible_text("Client Master")

        to_date = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='toDateUI']")))
        to_date.clear()
        to_date.send_keys(yesterday)
        to_date.send_keys(Keys.RETURN) 

        # Select CSV output
        output_dropdown = wait.until(EC.presence_of_element_located((By.XPATH, "//select[@id='output']")))
        Select(output_dropdown).select_by_visible_text("CSV")
        driver.save_screenshot(rf"{Screenshot}\{Master_filename}.png")
        # Click Submit
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="myTabContent"]/div/div[8]/div/button')))
        submit_button.click()

        # Wait for file link & download
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "//tbody[@id='executionData']/tr[1]/td[3]/a[1]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        time.sleep(2)   # Optional buffer time

        downloaded_file = wait_for_download(download_dir1,Master_filename)
        if downloaded_file:
            pass
        vMasterStatus = "Done"
    except Exception as e:
        driver.save_screenshot(rf"{Screenshot}\{Master_filename}.png")
        print(f"Error in downloading Master report: {e}")
        error = True
    finally:
        print("Process Completed. Closing browser.")
        driver.quit()  # Ensure browser is closed 
    return vMasterStatus,error
