import pandas as pd
import json

def run():
    df = pd.read_excel(r".\assets\config\ConfigFile.xlsx", header=0, index_col=0)
    c = {index: value for index, value in df.iloc[:, 0].items()}

    json_c = json.dumps(c)
    data = json.loads(json_c)

    shared_folder_path = data["shared_folder_path"]
    pending_payout_input_file_name = data["pending_payout_input_file_name"]
    email_master_file_name = data["email_master_file_name"]

    return {
        "shared_folder_path": shared_folder_path,
        "pending_payout_input_file_name": pending_payout_input_file_name,
        "email_master_file_name": email_master_file_name
    }