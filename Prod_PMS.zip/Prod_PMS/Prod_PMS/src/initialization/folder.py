from datetime import datetime, timedelta
import os
import pandas as pd
import shutil
import sys
from src.reusable import Email_Automation
from dotenv import load_dotenv 
load_dotenv()

Shared_Path = os.getenv('Shared_Path')
#print(Shared_Path)

Month_str = datetime.now().strftime("%b-%y")
#print(Month_str)

current_year = datetime.now().year % 100  # Get last two digits of the current year
Next_year = (datetime.now().year + 1) % 100  # Get last two digits of the previous year

year_str = f"Year_{current_year}_{Next_year}"
#print(year_str)

# Get yesterday's date (T-1)
# vyesterday = datetime.now().strftime("%d%B%Y")
vyesterday = (datetime.now() - timedelta(days=0)).strftime("%d%B%Y")
yesterday = (datetime.now() - timedelta(days=1)).strftime("%d/%m/%Y")

try:
    # Set download paths
    download_dir = rf"{Shared_Path}\DailyDownload_MasterFolder\{year_str}\{Month_str}\{vyesterday}"  # AUM download path
    download_dir1 = rf"{download_dir}_ALL"  # Flow & Master download path
    print(download_dir)
    os.makedirs(download_dir, exist_ok=True)
    os.makedirs(download_dir1, exist_ok=True)
    #print(download_dir1)

    #Set Screenshot paths
    Screenshot = rf"{Shared_Path}\Temporary_File"
    temp_path = rf"{Screenshot}\Output"

    # Load Excel file
    file_name = "PMS LOGIN PORTAL ACCESS.xlsx"
    file_path1 = rf"{Shared_Path}\Templates"
    file_path = rf"{file_path1}\{file_name}"

    # Source and destination paths
    source_path = os.path.join(file_path1, file_name)
    destination_path = os.path.join(download_dir, "PMS_Status.xlsx")
    # Copy the file
    if os.path.exists(source_path):
        # Check if file already exists at the destination
        if not os.path.exists(destination_path):
            shutil.copy2(source_path, destination_path)  # copy2 preserves metadata
            print(f"File copied to {destination_path}")
        else:
            print(f"File already exists at {destination_path}")
    else:
        print("Source file not found!")

    df = pd.read_excel(destination_path)
except Exception as e:
    e_type, e_obj, e_tb = sys.exc_info()
    print("Share_Folder_Access",str(e_tb.tb_lineno),"THIRD PARTY",e)
    Email_Automation.errorMail("Share_Folder_Access",str(e_tb.tb_lineno),"THIRD PARTY",e)
