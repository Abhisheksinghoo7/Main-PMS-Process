import os
import shutil
from src.initialization.folder import yesterday,df,temp_path
from src.initialization.utils import set_download_path
from src.initialization import carlien
from src.initialization import ask
from src.initialization import helois
from src.initialization import marcellus
from src.initialization import unifi
from src.initialization.white import white_login,white_AUM,white_Flow,white_Master
from src.initialization.buyant import buy_login,buy_AUM,buy_Flow,buyant_Master
from src.initialization import alf
from src.initialization.enam import enam_login,enam_AUM,enam_Flow,enam_Master
from src.initialization import sundaram
from src.initialization import old
from src.initialization.purantha import pur_login,pur_AUM,pur_Flow,pur_Master
from src.initialization.aditya import aditya_login,aditya_AUM,aditya_Flow,aditya_Master
from src.initialization.multi import multi_login,multi_AUM,multi_Flow,multi_Master
from src.initialization import oneamc
from src.initialization import one
from src.initialization.alchmey import alchmey_login,alchmey_AUM,alchmey_Flow,alchmey_Master

# Function for CARNELIAN PMS
def run_carnelian(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
      
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}" 
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name 
        driver, wait,error = carlien.login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = carlien.Carlein_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = carlien.Carlein_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = carlien.Carlein_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"

# Function for HELIOS PMS
def run_helois(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]

    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}" 
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = helois.helois_login(username, password, URL)
        if driver: 
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = helois.helois_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = helois.helois_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = helois.helois_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"

# Function for ASK PMS
def run_ask(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = ask.ask_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = ask.Ask_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = ask.Ask_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = ask.Ask_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
           
# Function for 360 PMS
def run_one(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        row_index = row.name 
        driver, wait,error = one.oneamc_login(username, password, URL)
        if driver:
            
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = one.oneamc_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                if CODE == "DIRECT CODE":
                    flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                else:
                    flow_filename = f"{FUND}_{CODE}_Client Flow.zip" 
                vFlowStatus, error = one.oneamc_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = one.oneamc_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"

# Function for 360 AMC PMS
def run_oneamc(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        row_index = row.name 
        driver, wait,error = oneamc.one_login(username, password, URL)
        if driver:
            
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = oneamc.one_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = oneamc.one_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = oneamc.one_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"

# Function for Marcellus PMS
def run_Marcellus(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = marcellus.marcellus_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = marcellus.marcellus_AUM(driver, wait, AUM_filename, download_dir3, yesterday)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = marcellus.marcellus_Flow(driver, wait, flow_filename, download_dir3, yesterday)
                df.at[row_index, "FLOW"] = vFlowStatus
                #print(vFlowStatus, error)
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = marcellus.marcellus_Master(driver, wait, Master_filename, download_dir3, yesterday)
                df.at[row_index, "MASTER"] = vMasterStatus
                #print(vMasterStatus, error)
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
           
# Function for Unifi PMS
def run_unifi(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = unifi.unifi_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = unifi.unifi_AUM(driver, wait, AUM_filename, download_dir3, yesterday)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = unifi.unifi_Flow(driver, wait, flow_filename, download_dir3, yesterday)
                df.at[row_index, "FLOW"] = vFlowStatus
                #print(vFlowStatus, error)
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = unifi.unifi_Master(driver, wait, Master_filename, download_dir3, yesterday)
                df.at[row_index, "MASTER"] = vMasterStatus
                #print(vMasterStatus, error)
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
              
# Function for White Oks PMS
def run_white(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = white_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = white_AUM(driver, wait, AUM_filename, download_dir3, yesterday)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = white_Flow(driver, wait, flow_filename, download_dir3, yesterday)
                df.at[row_index, "FLOW"] = vFlowStatus
                #print(vFlowStatus, error)
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = white_Master(driver, wait, Master_filename, download_dir3, yesterday)
                df.at[row_index, "MASTER"] = vMasterStatus
                #print(vMasterStatus, error)
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"

# Function for Buyant PMS
def run_buyant(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
      
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}" 
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name 
        driver, wait,error = buy_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = buy_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = buy_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = buyant_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
    print(f"[{FUND}] Processing completed.")  

# Function for alf PMS
def run_alf(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
      
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}" 
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name 
        driver, wait,error = alf.buy_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = alf.buy_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = alf.buy_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = alf.buy_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
    print(f"[{FUND}] Processing completed.")          

# Function for Enam PMS
def run_enam(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
      
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}" 
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name 
        driver, wait,error = enam_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = enam_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = enam_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = enam_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
    print(f"[{FUND}] Processing completed.")          

# Function for Sundaram PMS
def run_sundaram(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
      
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}" 
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name 
        driver, wait,error = sundaram.buy_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = sundaram.buy_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = sundaram.buy_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = sundaram.buy_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
    print(f"[{FUND}] Processing completed.") 

# Function for Old PMS
def run_old(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
      
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}" 
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name 
        driver, wait,error = old.buy_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = old.buy_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = old.buy_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = old.buy_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"
    print(f"[{FUND}] Processing completed.")   

# Function for Purantha PMS
def run_pur(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = pur_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = pur_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = pur_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = pur_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"     

# Function for ADITYA PMS
def run_aditya(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = aditya_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = aditya_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = aditya_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = aditya_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"

# Function for MULTI PMS
def run_multi(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = multi_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = multi_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = multi_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = multi_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"

# Function for ALCHEMY PMS
def run_alchmey(row):
    FUND = row.iloc[0]
    URL = row.iloc[1]
    username = row.iloc[2]
    password = row.iloc[3]
    CODE = row.iloc[4]
    status = row.iloc[5]
    aum_status = row.iloc[6]
    flow_status = row.iloc[7]
    master_status = row.iloc[8]
    
    if status != "Success":
        download_dir3 = rf"{temp_path}\{FUND}"
        os.makedirs(download_dir3, exist_ok=True)
        # Update DataFrame
        row_index = row.name  # Get index
        driver, wait,error = alchmey_login(username, password, URL)
        if driver:
            set_download_path(driver, download_dir3)
            if aum_status != "Done":
                AUM_filename = f"{FUND}_{CODE}.csv"
                vAumStatus, error = alchmey_AUM(driver, wait, AUM_filename, download_dir3)
                df.at[row_index, "AUM"] = vAumStatus
            if flow_status != "Done":
                flow_filename = f"{FUND}_{CODE}_Client Flow.csv"
                vFlowStatus, error = alchmey_Flow(driver, wait, flow_filename, download_dir3)
                df.at[row_index, "FLOW"] = vFlowStatus
            if master_status != "Done":
                Master_filename = f"{FUND}_{CODE}_Client Master.csv"
                vMasterStatus, error = alchmey_Master(driver, wait, Master_filename, download_dir3)
                df.at[row_index, "MASTER"] = vMasterStatus
            driver.quit()
            try:
                shutil.rmtree(download_dir3)
                print(f"Deleted folder: {download_dir3}")
            except FileNotFoundError:
                print("Folder does not exist.")
            
            if error:
                df.at[row_index, "Status"] = "Failed"
            else:
                df.at[row_index, "Status"] = "Success"                                    