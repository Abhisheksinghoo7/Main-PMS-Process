from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from src.initialization.folder import Screenshot,yesterday
from src.initialization import utils
import time

def ask_login(username, password, URL):
    """Log into the website and return the driver and wait object."""
    print("Starting login process...")
    driver = webdriver.Chrome(options=utils.chrome_options)
    wait = WebDriverWait(driver, 40)
    error = False
    try:
        driver.get(URL)

        # Enter credentials & login
        username_field = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='username']")))
        password_field = driver.find_element(By.XPATH, "//*[@id='password']")
        username_field.send_keys(username)
        password_field.send_keys(password)

        login_button = driver.find_element(By.XPATH, "/html/body/app-root[1]/layout[1]/empty-layout[1]/div[1]/div[1]/auth-sign-in[1]/div[1]/div[1]/div[1]/form[1]/button[1]")
        login_button.click()

        print("Login successful.")

        wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/fuse-vertical-navigation[1]/div[1]/div[2]/fuse-vertical-navigation-basic-item[5]/div[1]/a[1]"))).click()

        return driver, wait,error  # Return driver for further actions
    except Exception as e:
        print(f"Login failed: {e}")
        driver.save_screenshot(f"{Screenshot}\Ask_Login.png")
        error = True
        driver.quit()
        return None, None,error
time.sleep(2)
def Ask_AUM(driver, wait, AUM_filename, download_dir):
    """Automates downloading the AUM report and renaming it."""
    print("Navigating to AUM Report...")
    vAumStatus = "No"
    error = False
    try:
        utils.set_download_path(driver, download_dir)  # Set the correct directory
        
        #wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/fuse-vertical-navigation[1]/div[1]/div[2]/fuse-vertical-navigation-basic-item[5]/div[1]/a[1]"))).click()

        # Select "Clientwise Daily AUM"
        Aum_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer[1]/div[1]/app-queries-list[1]/div[1]/div[1]/div[3]/a[7]")))
        Aum_button.click()

        # Enter "From" and "To" dates
        '''from_date = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="mat-input-7"]')))
        to_date = driver.find_element(By.XPATH, '//*[@id="mat-input-8"]')
        from_date.send_keys(Keys.CONTROL + "a")
        from_date.send_keys(Keys.DELETE)
        time.sleep(1)
        from_date.send_keys(yesterday)
        time.sleep(5)
        
        to_date.send_keys(Keys.CONTROL + "a")
        to_date.send_keys(Keys.DELETE)
        time.sleep(1)
        to_date.send_keys(yesterday)'''

        from_date = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="mat-input-7"]')))
        to_date = driver.find_element(By.XPATH, '//*[@id="mat-input-8"]')

        # Clear using JavaScript
        driver.execute_script("arguments[0].value = '';", from_date)
        driver.execute_script("arguments[0].value = '';", to_date)

        # Enter dates
        time.sleep(2)
        from_date.send_keys(yesterday)
        time.sleep(2)
        to_date.send_keys(yesterday)

        # Select CSV output
        csv_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[1]")))
        csv_button.click()
        File_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[4]/div[2]/div[1]/div[1]/div[1]/button[1]")))
        File_button.click()
        # Click Submit and download
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[2]")))
        submit_button.click()

        # Wait for file link & download
        driver.save_screenshot(f"{Screenshot}\{AUM_filename}.png")
        time.sleep(30)
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root/layout/classy-layout/div[1]/div[2]/app-queries/div/mat-drawer-container/mat-drawer-content/div/div/app-queries-criteria/div/div[2]/div[2]/div/div/div[2]/table/tbody/tr/td[3]/button/span[3]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        time.sleep(2)  # Optional buffer time

        downloaded_file = utils.wait_for_download(download_dir,AUM_filename)
        if downloaded_file:
            pass
        vAumStatus = "Done"
    except Exception as e:
        driver.save_screenshot(f"{Screenshot}\{AUM_filename}.png")
        error = True
        print(f"Error in downloading AUM report: {e}")
    return vAumStatus,error

def Ask_Flow(driver, wait, flow_filename, download_dir1):
    """Automates downloading the Flow report and renaming it."""
    print("Navigating to Flow Report...")
    vFlowStatus = "No"
    error = False
    try:
        utils.set_download_path(driver, download_dir1)  # Set the correct directory

        # Select "Clientwise Daily Flow"
        flow_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root/layout/classy-layout/div[1]/div[2]/app-queries/div/mat-drawer-container/mat-drawer/div/app-queries-list/div/div[1]/div[3]/a[2]/span[2]/span")))
        flow_button.click()
        time.sleep(2)

        # Enter "From" and "To" dates
        from_date = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/mat-form-field[1]/div[1]/div[2]/div[2]/input[1]')))
        from_date.click()
        print("Click on date...")
        to_date = driver.find_element(By.XPATH, '/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/mat-form-field[1]/div[1]/div[2]/div[2]/input[1]')

        # Clear using JavaScript
        driver.execute_script("arguments[0].value = '';", from_date)
        driver.execute_script("arguments[0].value = '';", to_date)

        # Enter dates
        time.sleep(2)
        from_date.send_keys("01/01/2001")
        time.sleep(2)
        to_date.send_keys(yesterday)

        # Select CSV output
        csv_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[1]")))
        csv_button.click()
        File_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[4]/div[2]/div[1]/div[1]/div[1]/button[1]")))
        File_button.click()
        # Click Submit and download
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[2]")))
        submit_button.click()

        # Wait for file link & download
        time.sleep(40)
        driver.save_screenshot(f"{Screenshot}\{flow_filename}.png")
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root/layout/classy-layout/div[1]/div[2]/app-queries/div/mat-drawer-container/mat-drawer-content/div/div/app-queries-criteria/div/div[2]/div[2]/div/div/div[2]/table/tbody/tr/td[3]/button/span[3]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        time.sleep(3)  # Optional buffer time

        downloaded_file = utils.wait_for_download(download_dir1,flow_filename)
        if downloaded_file:
            pass
        vFlowStatus = "Done"

    except Exception as e:
        driver.save_screenshot(f"{Screenshot}\{flow_filename}.png")
        error = True
        print(f"Error in downloading Flow report: {e}")
    return vFlowStatus,error
def Ask_Master(driver, wait, Master_filename, download_dir1):
    """Automates downloading the Master report and renaming it."""
    print("Navigating to Master Report...")
    vMasterStatus = "No"
    error = False
    try:
        utils.set_download_path(driver, download_dir1)  # Set the correct directory

        #wait.until(EC.presence_of_element_located((By.ID, "boQueryLeftMenu"))).click()
        master_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root/layout/classy-layout/div[1]/div[2]/app-queries/div/mat-drawer-container/mat-drawer/div/app-queries-list/div/div[1]/div[3]/a[5]/span[2]/span")))
        master_button.click()
        time.sleep(2)

        # Enter "From" and "To" dates
        to_date = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/mat-form-field[1]/div[1]/div[2]/div[2]/input[1]')))

        # Clear using JavaScript
        driver.execute_script("arguments[0].value = '';", to_date)

        # Enter dates
        time.sleep(2)
        to_date.send_keys(yesterday)

        # Select CSV output
        csv_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[1]")))
        csv_button.click()
        File_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[4]/div[2]/div[1]/div[1]/div[1]/button[1]")))
        File_button.click()
        # Click Submit and download
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[2]")))
        submit_button.click()

        # Wait for file link & download
        time.sleep(20)
        driver.save_screenshot(f"{Screenshot}\{Master_filename}.png")
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root/layout/classy-layout/div[1]/div[2]/app-queries/div/mat-drawer-container/mat-drawer-content/div/div/app-queries-criteria/div/div[2]/div[2]/div/div/div[2]/table/tbody/tr/td[3]/button/span[3]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        time.sleep(2)  # Optional buffer time

        downloaded_file = utils.wait_for_download(download_dir1,Master_filename)
        if downloaded_file:
            pass
        vMasterStatus = "Done"
    except Exception as e:
        driver.save_screenshot(f"{Screenshot}\{Master_filename}.png")
        print(f"Error in downloading Master report: {e}")
        error = True

    finally:
        print("Process Completed. Closing browser.")
        driver.quit()  # Ensure browser is closed 
    return vMasterStatus, error