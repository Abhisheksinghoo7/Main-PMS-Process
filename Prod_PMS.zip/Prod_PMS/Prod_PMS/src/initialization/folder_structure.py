import sys
import os
from datetime import datetime
import traceback

"""Ensure path propperly appended"""
sys.path.append('.')

class FolderStructureConstants:
    current_date = datetime.now()
    current_year = current_date.strftime("%Y")
    current_month = current_date.strftime("%B")
    current_day = current_date.strftime("%d")
    root_fodlder = os.getcwd()

try:
    """Local Device folder structure"""
    Local_Device_Asset_Folder = os.path.join(FolderStructureConstants.root_fodlder, "assets")
    os.makedirs(Local_Device_Asset_Folder, exist_ok=True)

    Local_Device_Input_Folder = os.path.join(Local_Device_Asset_Folder, "input")
    os.makedirs(Local_Device_Input_Folder, exist_ok=True)

    Local_Device_Input_Date_Folder = os.path.join(Local_Device_Input_Folder, FolderStructureConstants.current_year, FolderStructureConstants.current_month, FolderStructureConstants.current_day)
    os.makedirs(Local_Device_Input_Date_Folder, exist_ok=True)

    Local_Device_Output_Folder = os.path.join(Local_Device_Asset_Folder, "output")
    os.makedirs(Local_Device_Output_Folder, exist_ok=True)

    Local_Device_Output_CurrentDate_Folder = os.path.join(Local_Device_Output_Folder, FolderStructureConstants.current_year, FolderStructureConstants.current_month, FolderStructureConstants.current_day)
    os.makedirs(Local_Device_Output_CurrentDate_Folder, exist_ok=True)

    Logs_Folder = os.path.join(Local_Device_Asset_Folder, "logs")
    os.makedirs(Logs_Folder, exist_ok=True)

    Error_Logs_Folder = os.path.join(Logs_Folder, "error_logs")
    os.makedirs(Error_Logs_Folder, exist_ok=True)

    CurrentDate_error_log_Folder = os.path.join(Error_Logs_Folder, FolderStructureConstants.current_year, FolderStructureConstants.current_month, FolderStructureConstants.current_day)
    os.makedirs(CurrentDate_error_log_Folder, exist_ok=True)

    Error_Screenshots_Folder = os.path.join(Logs_Folder, "error_screenshots")
    os.makedirs(Error_Screenshots_Folder, exist_ok=True)

    CurrentDate_error_screenshot_Folder = os.path.join(Error_Screenshots_Folder, FolderStructureConstants.current_year, FolderStructureConstants.current_month, FolderStructureConstants.current_day)
    os.makedirs(CurrentDate_error_screenshot_Folder, exist_ok=True)
except Exception as e:
    tb = traceback.extract_tb(e.__traceback__)
    print(tb)
    line_number = tb[-1][1]
    print(line_number)
    raise