from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from src.initialization.folder import Screenshot,yesterday
from src.initialization.utils import set_download_path, wait_for_download,chrome_options



def pur_login(username, password, URL):
    """Log into the website and return the driver and wait object."""
    print("Starting login process...")
    driver = webdriver.Chrome(options=chrome_options)
    wait = WebDriverWait(driver, 40)
    error = False
    try:
        driver.get(URL)
        try:
            wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[2]/div[2]/div[1]/mat-dialog-container[1]/div[1]/div[1]/app-login-message[1]/div[2]/div[2]/button[1]"))).click()
        except Exception as e:
            print(f"Login failed: {e}")
        # Enter credentials & login
        username_field = wait.until(EC.presence_of_element_located((By.XPATH, "//input[@id='username']")))
        password_field = driver.find_element(By.XPATH, "//*[@id='password']")
        username_field.send_keys(username)
        password_field.send_keys(password)

        login_button = driver.find_element(By.XPATH, "/html/body/app-root[1]/layout[1]/empty-layout[1]/div[1]/div[1]/auth-sign-in[1]/div[1]/div[1]/div[1]/form[1]/button[1]")
        login_button.click()

        print("Login successful.")

        wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/fuse-vertical-navigation[1]/div[1]/div[2]/fuse-vertical-navigation-basic-item[5]/div[1]/a[1]"))).click()

        return driver, wait,error  # Return driver for further actions
    except Exception as e:
        print(f"Login failed: {e}")
        driver.save_screenshot(f"{Screenshot}\Ask_Login.png")
        error = True
        driver.quit()
        return None, None,error

def pur_AUM(driver, wait, AUM_filename, download_dir):
    """Automates downloading the AUM report and renaming it."""
    print("Navigating to AUM Report...")
    vAumStatus = "No"
    error = False
    
    try:
        set_download_path(driver, download_dir)  # Set the correct directory
        
        Aum_button = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer[1]/div[1]/app-queries-list[1]/div[1]/div[1]/div[3]/a[9]")))
        driver.execute_script("arguments[0].scrollIntoView(true);", Aum_button)  # Scroll to the button

        Aum_button.click()
        time.sleep(2)
        from_date = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="mat-input-8"]')))
        to_date = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="mat-input-9"]')))
        driver.execute_script("arguments[0].value = '';", from_date)
        driver.execute_script("arguments[0].value = '';", to_date)
        print("clear")
        print("clear")
        # Enter dates
        time.sleep(2)
        from_date.send_keys(yesterday)
        time.sleep(2)
        to_date.send_keys(yesterday)

        # Select CSV output
        csv_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[1]")))
        csv_button.click()
        File_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]")))
        File_button.click()
        # Click Submit and download
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[2]")))
        submit_button.click()

        # Wait for file link & download
        time.sleep(30)
        driver.save_screenshot(f"{Screenshot}\{AUM_filename}.png")
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/button[1]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        #time.sleep(5)  # Optional buffer time

        downloaded_file = wait_for_download(download_dir,AUM_filename)
        #if downloaded_file:
            #rename_file(download_dir, AUM_filename,"aum")
        vAumStatus = "Done"
    except Exception as e:
        driver.save_screenshot(f"{Screenshot}\{AUM_filename}.png")
        error = True
        print(f"Error in downloading AUM report: {e}")
    #finally:
        #print("Process Completed. Closing browser.")
        #driver.quit()  # Ensure browser is closed 
    return vAumStatus,error

def pur_Flow(driver, wait, flow_filename, download_dir1):
    """Automates downloading the Flow report and renaming it."""
    print("Navigating to Flow Report...")
    vFlowStatus = "No"
    error = False
    try:
        set_download_path(driver, download_dir1)  # Set the correct directory

        # Select "Clientwise Daily Flow"
        flow_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer[1]/div[1]/app-queries-list[1]/div[1]/div[1]/div[3]/a[1]")))
        flow_button.click()
        time.sleep(2)

        # Enter "From" and "To" dates
        from_date = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/mat-form-field[1]/div[1]/div[2]/div[2]/input[1]')))
        from_date.click()
        print("Click on date...")
        to_date = driver.find_element(By.XPATH, '/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/mat-form-field[1]/div[1]/div[2]/div[2]/input[1]')

        # Clear using JavaScript
        driver.execute_script("arguments[0].value = '';", from_date)
        driver.execute_script("arguments[0].value = '';", to_date)

        # Enter dates
        time.sleep(2)
        from_date.send_keys("01/01/2001")
        time.sleep(2)
        to_date.send_keys(yesterday)

        # Select CSV output
        csv_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[1]")))
        csv_button.click()
        File_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]")))
        File_button.click()
        # Click Submit and download
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[2]")))
        submit_button.click()

        # Wait for file link & download
        time.sleep(30)
        driver.save_screenshot(f"{Screenshot}\{flow_filename}.png")
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/button[1]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        time.sleep(2)  # Optional buffer time

        downloaded_file = wait_for_download(download_dir1,flow_filename)
        #if downloaded_file:
            #rename_file(download_dir1, flow_filename,"flow")
        vFlowStatus = "Done"

    except Exception as e:
        driver.save_screenshot(f"{Screenshot}\{flow_filename}.png")
        error = True
        print(f"Error in downloading Flow report: {e}")
    return vFlowStatus,error
"""Automates downloading the Master report and renaming it."""
def pur_Master(driver, wait, Master_filename, download_dir1):
    vMasterStatus = "No"
    error = False  
    try:
        set_download_path(driver, download_dir1)  # Set the correct directory

        #wait.until(EC.presence_of_element_located((By.ID, "boQueryLeftMenu"))).click()
        master_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer[1]/div[1]/app-queries-list[1]/div[1]/div[1]/div[3]/a[4]")))
        master_button.click()
        time.sleep(2)

        # Enter "From" and "To" dates
        to_date = wait.until(EC.presence_of_element_located((By.XPATH, '/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/div[1]/mat-form-field[1]/div[1]/div[2]/div[2]/input[1]')))

        # Clear using JavaScript
        driver.execute_script("arguments[0].value = '';", to_date)

        # Enter dates
        time.sleep(2)
        to_date.send_keys(yesterday)

        # Select CSV output
        csv_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[1]")))
        csv_button.click()
        File_button = wait.until(EC.presence_of_element_located((By.XPATH, "/html/body/div[2]/div[2]/div[1]/div[1]/div[1]/button[1]")))
        File_button.click()
        # Click Submit and download
        submit_button = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[1]/button[2]")))
        submit_button.click()

        # Wait for file link & download
        time.sleep(20)
        driver.save_screenshot(f"{Screenshot}\{Master_filename}.png")
        print("Waiting for report to be available for download...")
        file_link = wait.until(EC.element_to_be_clickable((By.XPATH, "/html/body/app-root[1]/layout[1]/classy-layout[1]/div[1]/div[2]/app-queries[1]/div[1]/mat-drawer-container[1]/mat-drawer-content[1]/div[1]/div[1]/app-queries-criteria[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/button[1]")))
        file_link.click()

        print("File download initiated. Waiting for completion...")
        time.sleep(2)  # Optional buffer time

        downloaded_file = wait_for_download(download_dir1,Master_filename)
        #if downloaded_file:
            #rename_file(download_dir1, Master_filename,"master")
        vMasterStatus = "Done"
    except Exception as e:
        driver.save_screenshot(f"{Screenshot}\{Master_filename}.png")
        print(f"Error in downloading Master report: {e}")
        error = True

    return vMasterStatus, error