import os
import time
import shutil
from selenium import webdriver
from src.initialization.folder import download_dir, download_dir1

# Set Chrome options
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument("--start-maximized")
prefs = {"safebrowsing.enabled": True}
chrome_options.add_experimental_option("prefs", prefs)

def set_download_path(driver, path):
    """Dynamically sets the download directory."""
    driver.execute_cdp_cmd("Page.setDownloadBehavior", {"behavior": "allow", "downloadPath": path})

def wait_for_download(download_path, new_name, timeout=10):
    """Wait for the CSV file to finish downloading."""
    print(f"Waiting for file download in {download_path}...")
    end_time = time.time() + timeout

    while time.time() < end_time:
        #files = [f for f in os.listdir(download_path) if f.endswith(".csv",".zip")]
        files = [f for f in os.listdir(download_path) if f.endswith((".csv", ".zip"))]
        
        if files:
            latest_file = sorted(files, key=lambda f: os.path.getctime(os.path.join(download_path, f)), reverse=True)[0]
            print(f"File detected: {latest_file}")

            dst_path = os.path.join(download_path, latest_file)
            movedfile = os.path.join(download_path, new_name)
            os.rename(dst_path, movedfile)
            time.sleep(1)

            if "Flow" in new_name or "Master" in new_name:
                shutil.move(movedfile, download_dir1)
                time.sleep(1)
            else:
                shutil.move(movedfile, download_dir)
                time.sleep(1)

            return  # Exit the function immediately

        time.sleep(1)
    return None