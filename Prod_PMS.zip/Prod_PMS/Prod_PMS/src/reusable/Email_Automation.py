import os
import socket
import smtplib
import traceback
import logging
from jinja2 import Template, Environment, FileSystemLoader
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from dotenv import load_dotenv 
load_dotenv()

class EmailConfig:
    
    root_fodler = os.getcwd()
    EmailTo = os.getenv('MAIL_TO')
    EmailCC = os.getenv('MAIL_CC')
    SMTPServer=os.getenv('SMTPSERVER')
    SMTPPort=os.getenv('PORT')
    SMTPUsername = os.getenv('USER')
    SMTPPassword = os.getenv('PASSWORD')
    process_name = "Main PMS Process"
 
def send_email(subject, body, recipient, cc=None, attachments=None, screenshot_file=None, is_html=False):
    msg = MIMEMultipart()
    msg['From'] = EmailConfig.SMTPUsername
    msg['To'] = recipient
    msg['Cc'] = cc if cc else ""
    msg['Subject'] = subject
 
    """Set the body as HTML or plain text"""
    if is_html:
        msg.attach(MIMEText(body, 'html'))
    else:
        msg.attach(MIMEText(body, 'plain'))
 
    if attachments:
        for file in attachments:
            if os.path.exists(file):
                with open(file, "rb") as attachment:
                    part = MIMEApplication(attachment.read(), Name=os.path.basename(file))
                part['Content-Disposition'] = f'attachment; filename="{os.path.basename(file)}"'
                msg.attach(part)
            else:
                print(f"Attachment {file} does not exist or is invalid.")
    
    if screenshot_file:  # Assuming screenshot_file holds the path to the PNG file
        with open(screenshot_file, "rb") as attachment:
            part = MIMEApplication(attachment.read(), Name=os.path.basename(screenshot_file))
        part['Content-Disposition'] = f'attachment; filename="{os.path.basename(screenshot_file)}"'
        msg.attach(part)
 
    try:
        smtp_server = smtplib.SMTP(EmailConfig.SMTPServer, EmailConfig.SMTPPort)
        smtp_server.starttls()
        smtp_server.login(EmailConfig.SMTPUsername, EmailConfig.SMTPPassword)
        smtp_server.sendmail(EmailConfig.SMTPUsername, recipient.split(",") + (cc.split(",") if cc else []), msg.as_string())
        smtp_server.quit()
        logging.info("Email sent successfully.")
    except Exception as e:
        logging.error(f"Failed to send email: {str(e)}")
        traceback.print_exc()
 
"""Sending Start Mail"""
def start_Mail(entity):
    hostname = socket.gethostname()
    formatted_datetime = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    date, time1 = formatted_datetime.split()

    template_path = os.path.join(EmailConfig.root_fodler, "Prod_PMS","src", "template", "start_mail_template.html")
    #print(template_path)
    with open(template_path, "r") as file:
        html_template = file.read()

    """Render the HTML template using Jinja2"""
    template = Template(html_template)
    html_body = template.render(process_name=EmailConfig.process_name, instance=entity, start_date=date, start_time=time1)
    subject = f"[AA-BOT] : [PROD] : [{entity}] : [OPS] : [WTH] : [{EmailConfig.process_name}] : [Started] : [{date}] : [{time1}] : [{hostname}] : [SCH]"
    send_email(subject, html_body, EmailConfig.EmailTo, cc=EmailConfig.EmailCC, is_html=True)

"""Sending Successfull Mail"""
def successMail(entity, Path=None):
    hostname = socket.gethostname()
    formatted_datetime = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    date, time1 = formatted_datetime.split()

    template_path = os.path.join(EmailConfig.root_fodler,"Prod_PMS", "src", "template")
    #print(template_path)
    env = Environment(loader=FileSystemLoader(template_path))
    #print(env)
    template = env.get_template('success_mail_template.html')
    
    html_body = template.render(process_name=EmailConfig.process_name, instance=entity, completion_date=date, completion_time=time1,)
    subject = f"[AA-BOT] : [PROD] : [{entity}] : [OPS] : [WTH] : [{EmailConfig.process_name}] : [Success] : [{date}] : [{time1}] : [{hostname}] : [SCH]"
    attachments = Path if Path else None
    send_email(subject, html_body, EmailConfig.EmailTo, cc=EmailConfig.EmailCC, attachments=attachments, is_html=True)

"""Sending Error Mail"""
def errorMail(process_file_name, line_number, entity, e, Path=None):
    hostname = socket.gethostname()
    formatted_datetime = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    date, time1 = formatted_datetime.split()

    template_path = os.path.join(EmailConfig.root_fodler, "Prod_PMS","src", "template", "error_mail_template.html")
    with open(template_path, "r") as file:
        html_template = file.read()

    """Render the HTML template using Jinja2"""
    template = Template(html_template)
    html_body = template.render(process_name=EmailConfig.process_name, instance=entity, process_file=process_file_name, error_message=e, error_line_number=line_number, error_date=date, error_time=time1)
    subject = f"[AA-BOT] : [PROD] : [{entity}] : [OPS] : [WTH] : [{EmailConfig.process_name}] : [Failed] : [{date}] : [{time1}] : [{hostname}] : [SCH]"
    attachments = [Path] if Path else []
    send_email(subject, html_body, EmailConfig.EmailTo, cc=EmailConfig.EmailCC, attachments=attachments, is_html=True)